import tkinter as tk
from tkinter import messagebox, ttk, filedialog
from pytube import YouTube, Playlist
from threading import Thread

def browse_path():
    try:
        save_path = filedialog.askdirectory()
        path_entry.delete(0, tk.END)
        path_entry.insert(0, save_path)
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

def download():
    try:
        download_type = download_type_var.get()
        source_url = url_entry.get()
        save_path = path_entry.get()

        if download_type == "Single Video":
            try:
                yt = YouTube(source_url)
                video = yt.streams.filter(file_extension='mp4', resolution='720p').first()
                video.download(save_path)
                messagebox.showinfo("Success", "Video downloaded successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {e}")

        elif download_type == "Playlist":
            try:
                playlist = Playlist(source_url)
                for video in playlist.videos:
                    try:
                        yt = YouTube(video.watch_url)
                        video_stream = yt.streams.filter(file_extension='mp4', resolution='720p').first()
                        video_stream.download(save_path)
                        app.update_idletasks()
                    except Exception as e:
                        messagebox.showerror("Error", f"An error occurred: {e}")

                messagebox.showinfo("Success", "Playlist downloaded successfully.")
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {e}")

    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

# Create the main window
app = tk.Tk()
app.title("UADownloader")

# Create and place widgets
tk.Label(app, text="Download Type:").grid(row=0, column=0, padx=10, pady=10)
download_type_var = tk.StringVar()
download_type_var.set("Single Video")  # Default value
download_type_menu = ttk.Combobox(app, textvariable=download_type_var, values=["Single Video", "Playlist"])
download_type_menu.grid(row=0, column=1, padx=10, pady=10)

tk.Label(app, text="Source URL:").grid(row=1, column=0, padx=10, pady=10)
url_entry = tk.Entry(app, width=40)
url_entry.grid(row=1, column=1, padx=10, pady=10)

tk.Label(app, text="Save Path:").grid(row=2, column=0, padx=10, pady=10)
path_entry = tk.Entry(app, width=30)
path_entry.grid(row=2, column=1, padx=10, pady=10)

browse_button = tk.Button(app, text="Browse", command=browse_path)
browse_button.grid(row=2, column=2, padx=10, pady=10)

download_button = tk.Button(app, text="Download", command=download)
download_button.grid(row=3, column=0, columnspan=2, pady=10)

# Run the application
app.mainloop()
